#include<bits/stdc++.h>
using namespace std;

class Room {
protected:
    int nights;

public:
    Room(int _nights) : nights(_nights) {}

    virtual int revenue();
};

class Deluxe : public Room {
private:
    int service, serving;
public:
    Deluxe(int _nights, int _service, int _serving) : Room(_nights), service(_service), serving(_serving) {}

    int revenue() override;
};

class Premium : public Room {
private:
    int service;
public:
    Premium(int _nights, int _service) : Room(_nights), service(_service) {}

    int revenue() override;
};

class Business : public Room {
public:
    Business(int _nights) : Room(_nights) {}

    int revenue() override;
};


