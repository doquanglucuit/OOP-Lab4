#include<bits/stdc++.h>
#include "bai2.h"
using namespace std;

int main() {
    Deluxe a(4, 500000, 100000);
    Deluxe b(2, 450000, 150000);
    Premium c(3, 285000);
    Premium d(5, 375000);
    Business e(8);

    int deluxe = a.revenue() + b.revenue();
    int premium = c.revenue() + d.revenue();
    int business = e.revenue();

    string maxRoom;
    int ma = max({deluxe, premium, business});

    if (ma == deluxe) maxRoom = "Deluxe";
    else if (ma == premium) maxRoom = "Premium";
    else maxRoom = "Business";

    cout << "Loai phong co doanh thu cao nhat la " << maxRoom << " voi doanh thu la " << ma << endl;

    return 0;
}
