#include<bits/stdc++.h>
#include "bai3.h"
using namespace std;

int main() {
    int cow, sheep, goat;
    cout << "Nhap so con bo: ";
    cin >> cow;
    cout << "Nhap so con cuu: ";
    cin >> sheep;
    cout << "Nhap so con de: ";
    cin >> goat;

    cout << "\nTieng keu: "<< endl;

    Cow Cows(cow);
    Sheep Sheeps(sheep);
    Goat Goats(goat);

    Cows.tiengKeu();
    Sheeps.tiengKeu();
    Goats.tiengKeu();

    Cows.sinhCon();
    Cows.choSua();

    Sheeps.sinhCon();
    Sheeps.choSua();

    Goats.sinhCon();
    Goats.choSua();

    cout << "\n\nThong ke so luong con va so luong sua: " << endl;

    cout << "Bo: " << Cows.laySoLuongCon() << " con, " << Cows.laySoLuongSua() <<  " lit sua" << endl;
    cout << "Cuu: " << Sheeps.laySoLuongCon() << " con, " << Sheeps.laySoLuongSua() <<  " lit sua" << endl;
    cout << "De: " << Goats.laySoLuongCon() << " con, " << Goats.laySoLuongSua() <<  " lit sua" << endl;
    return 0;
}
