#include <bits/stdc++.h>
#include "bai3.h"
using namespace std;

void Animal::tiengKeu() {}

void Animal::choSua() {}

void Animal::sinhCon() {}

int Animal::laySoLuongCon() { return cnt; }

int Animal::laySoLuongSua(){ return milk; }

void Cow::tiengKeu() {
    for (int i = 0; i < cnt; i++)
        cout << "Bo doi" << ' ';
}

void Cow::choSua() {
    int temp = cnt;
    for (int i = 0; i < temp; i++) {
        milk += rand() % 21;
    }
}

void Cow::sinhCon() {
    int temp = cnt;
    for (int i = 0; i < temp; i++) {
        cnt += rand() % 3;
    }
}

void Sheep::tiengKeu() {
    int temp = cnt;
    for (int i = 0; i < temp; i++)
        cout << "Cuu doi" << ' ';
}

void Sheep::choSua() {
    int temp = cnt;
    for (int i = 0; i < temp; i++) {
        milk += rand() % 6;
    }
}

void Sheep::sinhCon() {
    int temp = cnt;
    for (int i = 0; i < temp; i++) {
        cnt += rand() % 3; //
    }
}

void Goat::tiengKeu() {
    for (int i = 0; i < cnt; i++)
        cout << "De doi" << ' ';
}

void Goat::choSua() {
    int temp = cnt;
    for (int i = 0; i < temp; i++) {
        milk += rand() % 11;
    }
}

void Goat::sinhCon() {
    int temp = cnt;
    for (int i = 0; i < temp; i++) {
        cnt += rand() % 3;
    }
}
