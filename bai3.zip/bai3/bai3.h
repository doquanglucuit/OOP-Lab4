#include <bits/stdc++.h>
using namespace std;

class Animal {
protected:
    int cnt;
    int milk;

public:
    Animal(int _cnt) : cnt(_cnt), milk(0) {}

    virtual void tiengKeu();
    virtual void choSua();
    virtual void sinhCon();

    int laySoLuongCon();
    int laySoLuongSua();
};

class Cow : public Animal {
public:
    Cow(int cnt) : Animal(cnt) {}

    void tiengKeu() override;

    void choSua() override;

    void sinhCon() override;
};

class Sheep : public Animal {
public:
    Sheep(int cnt) : Animal(cnt) {}

    void tiengKeu() override;

    void choSua() override;

    void sinhCon() override;
};

class Goat : public Animal {
public:
    Goat(int cnt) : Animal(cnt) {}

    void tiengKeu() override;

    void choSua() override;

    void sinhCon() override;
};
