#include<bits/stdc++.h>
using namespace std;

class NhanVien {
protected:
    string maSo;
    string ten;
    double luongCoBan;

public:
    NhanVien(string _maSo, string _ten, double _luong)
        : maSo(_maSo), ten(_ten), luongCoBan(_luong) {}

    virtual double TienThuong() = 0;
    virtual void Xuat();
};

class QuanLy : public NhanVien {
private:
    double tyLeThuong;

public:
    QuanLy(string _maSo, string _ten, double _luong, double _thuong)
        : NhanVien(_maSo, _ten, _luong), tyLeThuong(_thuong) {}

    double TienThuong() override;

    void Xuat() override;
};

class KySu : public NhanVien {
private:
    int soGioLamThem;

public:
    KySu(string _maSo, string _ten, double _luong, int _gio)
        : NhanVien(_maSo, _ten, _luong), soGioLamThem(_gio) {}

    double TienThuong() override;

    void Xuat() override;
};

